from tp4_ejercicio1 import generar_informe1
from tp4_ejercicio2 import generar_informe2
from tp4_ejercicio3 import generar_informe3

if __name__ == "__main__":
    # Configuración
    carpeta_imagenes = "TP4_imagenes"
    num_imagenes = 126

    # EJERCICIO 1.
    generar_informe1(carpeta_imagenes, num_imagenes)

    #EJERCICIO 2.
    generar_informe2()

    #EJERCICIO 3.
    generar_informe3()